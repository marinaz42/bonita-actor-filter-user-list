package fr.ujmse.filter;

import org.bonitasoft.engine.filter.AbstractUserFilter;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractUserListImpl extends AbstractUserFilter {

	protected final static String USERLIST_INPUT_PARAMETER = "userList";

	protected final java.util.List getUserList() {
		return (java.util.List) getInputParameter(USERLIST_INPUT_PARAMETER);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getUserList();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("userList type is invalid");
		}

	}

}
